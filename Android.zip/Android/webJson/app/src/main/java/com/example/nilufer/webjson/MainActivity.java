package com.example.nilufer.webjson;

import android.app.VoiceInteractor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;

    private static final String URL_DATA="http://192.168.1.13:8080/WebApplication7/faces/webresources/testcontroller/getData";
    private List<ListItem> listItems;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        System.out.println("dasasdasd");
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        listItems = new ArrayList<>();
        adapter = new adapter(listItems,getApplicationContext());


        System.out.println("saddasdasd");
        loadRecyclerViewData();
        recyclerView.setAdapter(adapter);

    }
    private void loadRecyclerViewData(){
        System.out.println("method kısımı");
        StringRequest stringRequest=new StringRequest(Request.Method.GET, URL_DATA,
                new Response.Listener<String>() {


                    @Override
                    public void onResponse(String response) {
                        try {

                            //JSONObject jsonObject=new JSONObject(response);
                            JSONArray array=new JSONArray(response);
                            System.out.println("response kısımı : "+response);
                            System.out.println("fetch kısımı");
                            for (int i=0;i<array.length();i++)
                            {
                                JSONObject object=array.getJSONObject(i);
                                ListItem item=new ListItem(object.getString("haber_baslik"),
                                        object.getString("haber_icerik"),object.getString("haber_turu")

                                        ,object.getString("tarih")
                                );
                                listItems.add(item);
                                System.out.println(item);

                            }
                           adapter.notifyDataSetChanged();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                }
        );
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                50000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }
}
