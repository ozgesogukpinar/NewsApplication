package com.example.nilufer.webjson;

import java.util.Date;

public class ListItem {
    private int haberID;
    private String haberResim;
    private String haberBaslik;
    private String haberIcerik;
    private String haberTuru;
    private String tarih;
    private int likes;
    private int dislike;

    public ListItem(int haberID, String haberResim, String haberBaslik, String haberIcerik, String haberTuru, String tarih, int likes, int dislike) {
        this.haberID = haberID;
        this.haberResim = haberResim;
        this.haberBaslik = haberBaslik;
        this.haberIcerik = haberIcerik;
        this.haberTuru = haberTuru;
        this.tarih = tarih;
        this.likes = likes;
        this.dislike = dislike;
    }

    public ListItem(String haber_baslik, String haber_icerik, String haber_turu, String tarih) {
        this.dislike = dislike;
        this.haberID = haberID;
        this.haberResim = haberResim;
        this.haberBaslik = haberBaslik;
        this.haberIcerik = haberIcerik;
        this.haberTuru = haberTuru;
        this.tarih = tarih;
        this.likes = likes;

    }

    public int getHaberID() {
        return haberID;
    }

    public void setHaberID(int haberID) {
        this.haberID = haberID;
    }

    public String getHaberResim() {
        return haberResim;
    }

    public void setHaberResim(String haberResim) {
        this.haberResim = haberResim;
    }

    public String getHaberBaslik() {
        return haberBaslik;
    }

    public void setHaberBaslik(String haberBaslik) {
        this.haberBaslik = haberBaslik;
    }

    public String getHaberIcerik() {
        return haberIcerik;
    }

    public void setHaberIcerik(String haberIcerik) {
        this.haberIcerik = haberIcerik;
    }

    public String getHaberTuru() {
        return haberTuru;
    }

    public void setHaberTuru(String haberTuru) {
        this.haberTuru = haberTuru;
    }

    public String getTarih() {
        return tarih;
    }

    public void setTarih(String tarih) {
        this.tarih = tarih;
    }

    public int getLikes() {
        return likes;
    }

    public void setLikes(int likes) {
        this.likes = likes;
    }

    public int getDislike() {
        return dislike;
    }

    public void setDislike(int dislike) {
        this.dislike = dislike;
    }
}
